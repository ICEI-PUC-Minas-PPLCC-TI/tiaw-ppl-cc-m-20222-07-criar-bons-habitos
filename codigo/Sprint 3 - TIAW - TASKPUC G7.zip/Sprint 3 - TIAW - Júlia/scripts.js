
let opcao_escolhida = [];
var soma = 0;
let objDados = {};






function resp(num_pergunta, selecionada){
    opcao_escolhida[num_pergunta] = selecionada.value;

    id="p" + num_pergunta;
    labels = document.getElementById(id).childNodes;
    labels[3].style.backgroundColor = "white";
    labels[5].style.backgroundColor = "white";
    labels[7].style.backgroundColor = "white";

  selecionada.parentNode.style.backgroundColor = " #f3b6281c";
}

/*======================================================================*/


function leDados(){
    let strDados = localStorage.getItem('db');
    if(strDados){
        objDados = JSON.parse(strDados);
    } 
    else {
        objDados = {quiz: [{perg1: ""},
                           {perg2: ""},
                           {perg3: ""},
                           {perg4: ""},
                           {perg5: ""} ]};
    }

    return objDados;
}

function salvaDados (dados){
    localStorage.setItem('db', JSON.stringify(dados));
}

function incluirPerg(){
    let objDados = leDados();
    // console.log(objDados);

    // console.log(objDados.quiz.length);

    
    // console.log(objDados.quiz[tamanho-1]);
    // console.log(Object.values(objDados.quiz[tamanho-1]));

 

    let strPerg1 = document.querySelector('input[name="p0"]:checked').value;
    let strPerg2 = document.querySelector('input[name="p1"]:checked').value;
    let strPerg3 = document.querySelector('input[name="p2"]:checked').value;
    let strPerg4 = document.querySelector('input[name="p3"]:checked').value;
    let strPerg5 = document.querySelector('input[name="p4"]:checked').value;
    let resposta = {
        perg1: strPerg1,
        perg2: strPerg2,
        perg3: strPerg3,
        perg4: strPerg4,
        perg5: strPerg5
    };

    // console.log(resposta);


    objDados.quiz.push(resposta);



    salvaDados(objDados);
    var tamanho = objDados.quiz.length;
    console.log(tamanho);
    console.log(objDados.quiz[tamanho-1]);
    let valorResp = Object.values(objDados.quiz[tamanho-1]);
    
    for(i=0; i<5; i++){
        soma+= Number(valorResp[i]);

        // console.log(valorResp[i]);
    }
    // console.log(soma);
    exibeResult();

    // somaQuiz();
}


/*============================================================ AULA ROMMEL    */

function somaQuiz(){
    

    for (i=0; i<5; i++){        
      soma += objDados[i];
      console.log(objDados[i]);
      console.log(soma);
    }
    localStorage.getItem('db');

    return soma;


}

function exibeResult(){
    let divPai =  document.getElementById('ctn1');
    divPai.innerHTML  = "";

    if (soma == 5){
        divPai.innerHTML =  `<section>
        <h2>Parabéns, suas respostas foram computadas!</h2>
        <h2> Veja suas recomendações: </h2>
       
        <h3>Recomendamos que você estude pelo menos 3 vezes na semana;  </h3>
        <h3>Aumente sua grade de matérias em pelo menos mais 3 matérias; </h3>
        <h3>Aumente o tempo gasto estudando em pelo menos 1 hora; </h3>
        <h3>Descubra pelo menos 2 novas maneiras de obter informações e aprendizados; </h3>
        <h3>Encontre pelo menos 3 novas maneiras de sanar suas duvidas. </h3>

                            </section>`;

        console.log('certo5');
    }

    else if(soma>5 && soma<= 10){
        divPai.innerHTML =  `<section>
        <h2>Parabéns, suas respostas foram computadas!</h2>
        <h2> Veja suas recomendações: </h2>

        <h3>Recomendamos que você estude pelo menos mais 2 vezes na semana;  </h3>
        <h3>Aumente sua grade de matérias em pelo menos mais 2 matérias; </h3>
        <h3>Aumente o tempo gasto estudando em pelo menos 30minutos; </h3>
        <h3>Descubra pelo menos 1 nova maneira de obter informações e aprendizados; </h3>
        <h3>Encontre pelo menos 3 novas maneiras de sanar suas duvidas. </h3>
 

                            </section>`;

        console.log('certo10');
    }
    else if(soma>10 && soma <= 15){
        divPai.innerHTML =  `<section>
                                     <h2>Parabéns, suas respostas foram computadas!</h2>
                                     <h2> Veja suas recomendações: </h2>
                                     
                                     <h3>Recomendamos que você estude pelo menos mais 1 vez na semana;  </h3>
                                     <h3>Aumente sua grade de matérias em pelo menos mais 1 matéria; </h3>
                                     <h3>Aumente o tempo gasto estudando em pelo menos 30 minutos; </h3>
                                     <h3>Descubra pelo menos 1 novas maneiras de obter informações e aprendizados; </h3>
                                     <h3>Encontre pelo menos 2 novas maneiras de sanar suas duvidas. </h3>
                             
                            </section>`;

        console.log('certo20');
    }
    else if(soma>15 && soma <= 20){
        divPai.innerHTML =  `<section>
                                     <h2>Parabéns, suas respostas foram computadas!</h2>
                                     <h2> Veja suas recomendações: </h2>

                                     <h3>Você está indo bem, com o TaskPUC você irá incrementar mais ainda suas habilidades! Criaremos configurações únicas e especiais para você!  </h3> 
                            </section>`;

        console.log('certo20');
    }
}





function imprimeDados(){
    let tela = document.getElementById('tela');
    let strHtml = '';

}

function btnenviar(){
    alert('funcionando');
}

// Configura botão:



document.getElementById ('enviaar').addEventListener('click',incluirPerg);


