function leDados() {
    let srtDados = localStorage.getItem('db')
    let objDados = {};
    
    if (srtDados) {
        objDados = JSON.parse(srtDados);
    }
    else{
        objDados = { lembretes: [
            { Hora: "19:00" ,
             Lembrete: "Academia" }] 
        }
    }
    return objDados;
}
function salvaDados(dados) {
    localStorage.setItem('db', JSON.stringify (dados));
}

function incluirLembrete() {
    let objDados = leDados();



    let strHora = document.getElementById('CampoHoras').value;
    let strLembrete = document.getElementById('CampoLembretes').value;

    let novoLembrete = {
        Hora: strHora,
        Lembrete: strLembrete,
    };

    objDados.lembretes.push (novoLembrete);
    salvaDados(objDados);
}


function ImprimeDados(){
let tela = document.getElementById('tela');
let strHtml = '';
let objDados = leDados();
for (i=0; i< objDados.lembretes.length; i++){
    strHtml += `<p>${objDados.lembretes[i].Hora} - ${objDados.lembretes[i].Lembrete} </p> `
}
document.getElementById('tela').innerHTML = strHtml;
}
// Configuração dos botões 
document.getElementById('button').addEventListener('click', incluirLembrete);
document. getElementById('BtnIncluirLembrete').addEventListener('click', ImprimeDados);
